export const animationTime = 1000;
export const US_NAME = 'United States';
export const SOUTH_KOREA = 'South Korea';
export const GLOBAL_PAPER_OPACITY = 0.9;
