function sort(arr, func) {
  return arr.concat().sort(func);
}

export default sort;
