module.exports = {
  title: 'Coronavírus BR',
  description:
    'O Coronavírus BR é um site desenvolvido com o intuito de ajudar o povo brasileiro no controle da pandemia de COVID-19.',
  author: '@henry-ns',
};
