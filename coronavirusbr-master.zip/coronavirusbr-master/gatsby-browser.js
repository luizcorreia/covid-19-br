import 'typeface-poppins';

export { wrapRootElement } from './gatsby/wrapRootElement';
