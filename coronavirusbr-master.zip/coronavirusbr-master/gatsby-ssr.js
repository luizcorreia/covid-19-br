export { wrapRootElement } from './gatsby/wrapRootElement';
