export default {
  smallPhone: '400px',
  phone: '500px',
  bigPhone: '620px',
  smallTablet: '720px',
  tablet: '900px',
  smallDesktop: '1038px',
  hd: '1366px',
};
